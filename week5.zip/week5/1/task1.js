
function dollar(){
	var a = document.getElementById("kzt").value;
	var b = document.getElementByName("select").value;
	usd = a / 380;
	if (document.getElementById("Dollar").checked) {
		document.getElementById("result").value = usd.toFixed(2) + " $"

		} 
	}	
	document.getElementById("Dollar").checked = true;
	document.getElementById("Euro").checked = false;

function euro(){
	var a = document.getElementById("kzt").value;
	var b = document.getElementByName("select").value;
	var euro = a / 420;
	if (document.getElementById("Euro").checked) {
		document.getElementById("result").value = euro.toFixed(2) + " €"; 
		if (b == "euro") {
			document.getElementById("result").value = euro.toFixed(2) + " €";

		} 
	}	
	document.getElementById("Dollar").checked = false;
	document.getElementById("Euro").checked = true;
}
function currency(){
	var a=document.getElementByName(select).value
}