function engtrans() {
	document.querySelector("h1").innerHTML="Header of the website";
	document.querySelector("nav").innerHTML="Navigation";
	document.querySelector("footer").innerHTML="Footer of website";
	document.querySelector("#p_1").innerHTML="Description 1";
	document.querySelector("#p_2").innerHTML="Description 2";
	document.querySelector("aside").innerHTML="Aside Bar";
	document.getElementById("e").checked = true;
	document.getElementById("r").checked = false;
}
function rustrans() {
	document.querySelector("h1").innerHTML="Заголовок";
	document.querySelector("nav").innerHTML="Навигация";
	document.querySelector("footer").innerHTML="Подвал сайта";
	document.querySelector("#p_1").innerHTML="Описание 1";
	document.querySelector("#p_2").innerHTML="Описание 2";
	document.querySelector("aside").innerHTML="Сайдбар";
	document.getElementById("r").checked = true;
	document.getElementById("e").checked = false;
}

