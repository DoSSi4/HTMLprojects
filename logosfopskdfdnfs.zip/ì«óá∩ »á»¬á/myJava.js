function rustrans() {
	document.querySelector("nav").innerHTML;
	document.querySelector("#home").innerHTML="Дом";
	document.querySelector("#stad").innerHTML="Стадион";
	document.querySelector("#sqd").innerHTML="Состав";
	document.querySelector("#games").innerHTML="Игры";
	document.querySelector("#his").innerHTML="О клубе";
	document.getElementById("r").checked = true;
	document.getElementById("e").checked = false;
}
function engtrans() {
	document.querySelector("#home").innerHTML="Home";
	document.querySelector("#stad").innerHTML="Stadium";
	document.querySelector("#sqd").innerHTML="Squad";
	document.querySelector("#games").innerHTML="Games";
	document.querySelector("#his").innerHTML="History";
	document.querySelector("nav").innerHTML;
	document.getElementById("e").checked = true;
	document.getElementById("r").checked = false;
}

